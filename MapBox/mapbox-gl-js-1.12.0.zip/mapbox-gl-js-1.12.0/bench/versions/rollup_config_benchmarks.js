
import allConfigs from '../rollup_config_benchmarks.js';

export default allConfigs.slice(0, 2);
