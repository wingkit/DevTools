// @flow
// ONE_EM constant used to go between "em" units used in style spec and "points" used internally for layout

export default 24;
