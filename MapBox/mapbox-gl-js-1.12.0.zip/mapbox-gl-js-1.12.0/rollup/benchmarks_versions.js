import './build/benchmarks/versions/shared';
import './build/benchmarks/versions/worker';
import './build/benchmarks/versions/benchmarks';
